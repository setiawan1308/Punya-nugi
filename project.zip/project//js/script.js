
        document.getElementById("registerForm").addEventListener("submit", function(e) {
            e.preventDefault();

            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const phone = document.getElementById("phone").value;
            const birthdate = document.getElementById("birthdate").value;
            const gender = document.querySelector("input[name='gender']:checked").value;

            const table = document.getElementById("dataTable").getElementsByTagName('tbody')[0];
            const newRow = table.insertRow();

            newRow.insertCell().textContent = name;
            newRow.insertCell().textContent = email;
            newRow.insertCell().textContent = phone;
            newRow.insertCell().textContent = birthdate;
            newRow.insertCell().textContent = gender;

            document.getElementById("registerForm").reset();
        });
